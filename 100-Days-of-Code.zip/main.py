#import Multiple_if_statements
#import RollerCoaster
#import Pizza_order
#import Love_calc
#import Treasure_island
#import RandomModule
#import Heads_or_Tails
#import LeapYear
#import lists_buyer
#import Treasure_map
#import Rock_Paper_Scissors
#import Average_height
#import High_score
#import Adding_even_numbers
#import The_FizzBuzz_Job_Interview_Question
#import Great_password_generator
#from Hangman import hangman_code
#from Hangman import hangman_words
#import tick_tack_toe
#import func
#import Paint_area_calc
#import Prime_number_checker
#from Ceasar_cipher import Ceaser_cipher_2
#import grading_program
#from secret_auction_prog import secret_auction
#import days_in_month
#from Calculator import calculator
#from BlackJack import black_jack
#from BlackJack import blackjack_solution
#import guessing_game
from Higher_lower_game import higher_lower_game