# def greet(name):
#     print(f"Hello {name}")
#     print(f"How are you? {name}")
    

# greet("Bill")


def greet_with(name, location):
    print(f"Hello {name}")
    print(f"What is it like in? {location}")
    

greet_with(location="Brazil", name="Petos")