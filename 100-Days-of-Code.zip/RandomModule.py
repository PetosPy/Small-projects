import random 
random_int = random.randint(1,10)
print(random_int)

import random
floating = random.random()
print(floating * 6)