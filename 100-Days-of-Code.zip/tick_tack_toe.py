import random

# Make a list for the gamepad>

line_1 = ["⬜","⬜️","⬜️"]
line_2 = ["⬜️","⬜️","⬜️"]
line_3 = ["⬜️","⬜️","⬜️"]



print(game)